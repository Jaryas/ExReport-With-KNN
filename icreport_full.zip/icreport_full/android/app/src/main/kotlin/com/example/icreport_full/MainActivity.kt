package com.example.icreport_full

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
