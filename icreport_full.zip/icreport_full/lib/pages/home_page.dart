import 'package:flutter/material.dart';
import '../db/database_helper.dart';
import 'notif_banner.dart';
import 'knn_helper.dart';
import 'evaluasi_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  bool showNotif = false;

  String notifText = '';

  @override
  void initState() {
    super.initState();
    checkExpiring();
  }

  void checkExpiring() async {

    List items = await DatabaseHelper().getItems();

    DateTime now = DateTime.now();

    for (var d in items) {

      DateTime exp = DateTime.parse(d['expired_date']);

      int selisihHari = exp.difference(now).inDays;

      String hasilKNN = KNNHelper.classify(selisihHari);

      if (hasilKNN == 'Kedaluwarsa') {
        setState(() {
          showNotif = true;
          notifText = 'Ada barang yang sudah expired.';
        });
        return;
      }

      if (hasilKNN == 'Mendekati') {
        setState(() {
          showNotif = true;
          notifText = 'Ada barang mendekati expired.';
        });
        return;
      }
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(
        title: const Text('ExReport - Home'),
      ),

      body: Column(

        children: [

          if (showNotif)
            NotifBanner(message: notifText),

          Expanded(

            child: Center(

              child: Wrap(

                spacing: 12,
                runSpacing: 12,
                alignment: WrapAlignment.center,

                children: [

                  ElevatedButton.icon(
                    icon: const Icon(Icons.qr_code_scanner),
                    label: const Text('Scan Barang'),
                    onPressed: () => Navigator.pushNamed(context, '/scan'),
                  ),

                  ElevatedButton.icon(
                    icon: const Icon(Icons.add_box),
                    label: const Text('Input Manual'),
                    onPressed: () => Navigator.pushNamed(context, '/input'),
                  ),

                  ElevatedButton.icon(
                    icon: const Icon(Icons.list),
                    label: const Text('List Barang'),
                    onPressed: () => Navigator.pushNamed(context, '/list'),
                  ),

                  ElevatedButton.icon(
                    icon: const Icon(Icons.file_download),
                    label: const Text('Export Excel'),
                    onPressed: () => Navigator.pushNamed(context, '/export'),
                  ),

                  // TOMBOL BARU: EVALUASI MODEL
                  ElevatedButton.icon(
                    icon: const Icon(Icons.analytics),
                    label: const Text('Evaluasi Model'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue.shade700,
                      foregroundColor: Colors.white,
                    ),
                    onPressed: () => Navigator.pushNamed(context, '/evaluasi'),
                  ),

                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}