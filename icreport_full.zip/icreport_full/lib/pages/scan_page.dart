import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

class ScanPage extends StatefulWidget {
  const ScanPage({super.key});

  @override
  State<ScanPage> createState() => _ScanPageState();
}

class _ScanPageState extends State<ScanPage> {
  String code = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Scan Barcode')),
      body: Column(
        children: [
          Expanded(
            child: MobileScanner(
              onDetect: (capture) {
                final List<Barcode> barcodes = capture.barcodes;
                if (barcodes.isNotEmpty) {
                  final raw = barcodes.first.rawValue;
                  if (raw != null) {
                    setState(() => code = raw);
                  }
                }
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              children: [
                Text('Hasil: $code'),
                const SizedBox(height: 8),
                ElevatedButton(
                  onPressed: code.isEmpty
                      ? null
                      : () {
                    Navigator.pushNamed(
                      context,
                      '/input',
                      arguments: code,
                    );
                  },
                  child: const Text('Input dengan kode ini'),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}
