import 'package:flutter/material.dart';
import '../db/database_helper.dart';
import 'knn_helper.dart';

class ListBarangPage extends StatefulWidget {
  const ListBarangPage({super.key});

  @override
  State<ListBarangPage> createState() => _ListBarangPageState();
}

class _ListBarangPageState extends State<ListBarangPage> {

  List items = [];

  String filter = 'all';

  String sort = 'asc';

  @override
  void initState() {
    super.initState();
    load();
  }

  void load() async {

    List data = await DatabaseHelper().getItems(
      orderBy:
      'expired_date ${sort == 'asc' ? 'ASC' : 'DESC'}',
    );

    DateTime now = DateTime.now();

    if (filter == 'all') {

      items = data;

    } else if (filter == 'near') {

      items = data.where((d) {

        DateTime exp =
        DateTime.parse(d['expired_date']);

        int selisihHari =
            exp.difference(now).inDays;

        return KNNHelper.classify(selisihHari)
            == 'Mendekati';

      }).toList();

    } else if (filter == 'expired') {

      items = data.where((d) {

        DateTime exp =
        DateTime.parse(d['expired_date']);

        int selisihHari =
            exp.difference(now).inDays;

        return KNNHelper.classify(selisihHari)
            == 'Kedaluwarsa';

      }).toList();
    }

    setState(() {});
  }

  void deleteItem(int id) async {
    await DatabaseHelper().deleteItem(id);
    load();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        title: const Text('Data Barang'),

        actions: [

          PopupMenuButton<String>(

            onSelected: (v) {

              if (v == 'asc' || v == 'desc') {

                sort = v;

              } else {

                filter = v;
              }

              load();
            },

            itemBuilder: (_) =>
            <PopupMenuEntry<String>>[

              const PopupMenuItem(
                value: 'all',
                child: Text('Semua Barang'),
              ),

              const PopupMenuItem(
                value: 'near',
                child: Text(
                    'Hampir Expired'),
              ),

              const PopupMenuItem(
                value: 'expired',
                child: Text(
                    'Sudah Expired'),
              ),

              const PopupMenuDivider(),

              const PopupMenuItem(
                value: 'asc',
                child: Text(
                    'Sortir: Terdekat'),
              ),

              const PopupMenuItem(
                value: 'desc',
                child: Text(
                    'Sortir: Terjauh'),
              ),
            ],
          )
        ],
      ),

      body: items.isEmpty

          ? const Center(
        child: Text('Belum ada data'),
      )

          : ListView.builder(

        itemCount: items.length,

        itemBuilder: (_, i) {

          var d = items[i];

          DateTime exp =
          DateTime.parse(
              d['expired_date']);

          int selisihHari =
              exp.difference(
                  DateTime.now()).inDays;

          String hasilKNN =
          KNNHelper.classify(
              selisihHari);

          return Card(

            margin:
            const EdgeInsets.symmetric(
              horizontal: 12,
              vertical: 6,
            ),

            child: ListTile(

              title:
              Text(d['nama_barang']),

              subtitle: Text(

                'Expired : '
                    '${d['expired_date']}\n'

                    'Retur : '
                    '${d['tanggal_retur']}\n'

                    'Status : '
                    '$hasilKNN',
              ),

              trailing: IconButton(

                icon:
                const Icon(Icons.delete),

                onPressed: () =>
                    deleteItem(d['id']),
              ),
            ),
          );
        },
      ),
    );
  }
}