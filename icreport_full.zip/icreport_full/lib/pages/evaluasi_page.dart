import 'package:flutter/material.dart';
import '../db/database_helper.dart';
import 'knn_helper.dart';

class EvaluasiPage extends StatefulWidget {
  const EvaluasiPage({super.key});

  @override
  State<EvaluasiPage> createState() => _EvaluasiPageState();
}

class _EvaluasiPageState extends State<EvaluasiPage> {
  bool loading = true;

  // Confusion matrix: cm[aktual][prediksi]
  Map<String, Map<String, int>> cm = {
    'Aman':        {'Aman': 0, 'Mendekati': 0, 'Kedaluwarsa': 0},
    'Mendekati':   {'Aman': 0, 'Mendekati': 0, 'Kedaluwarsa': 0},
    'Kedaluwarsa': {'Aman': 0, 'Mendekati': 0, 'Kedaluwarsa': 0},
  };

  int totalData = 0;
  int totalBenar = 0;

  Map<String, double> precision = {};
  Map<String, double> recall = {};
  Map<String, double> f1 = {};

  double akurasi = 0;
  double macroPrecision = 0;
  double macroRecall = 0;
  double macroF1 = 0;

  final List<String> kelas = ['Aman', 'Mendekati', 'Kedaluwarsa'];

  // Tentukan label aktual berdasarkan aturan bisnis
  String aktualLabel(int selisihHari) {
    if (selisihHari > 30) return 'Aman';
    if (selisihHari >= 1) return 'Mendekati';
    return 'Kedaluwarsa';
  }

  @override
  void initState() {
    super.initState();
    hitungEvaluasi();
  }

  Future<void> hitungEvaluasi() async {
    List data = await DatabaseHelper().getItems();
    DateTime now = DateTime.now();

    // Reset confusion matrix
    for (var k in kelas) {
      for (var p in kelas) {
        cm[k]![p] = 0;
      }
    }

    totalData = data.length;
    totalBenar = 0;

    for (var d in data) {
      DateTime exp = DateTime.parse(d['expired_date']);
      int selisihHari = exp.difference(now).inDays;

      String aktual = aktualLabel(selisihHari);
      String prediksi = KNNHelper.classify(selisihHari);

      cm[aktual]![prediksi] = (cm[aktual]![prediksi] ?? 0) + 1;
      if (aktual == prediksi) totalBenar++;
    }

    // Hitung precision, recall, f1 per kelas
    for (var k in kelas) {
      int tp = cm[k]![k]!;

      int fpSum = 0;
      for (var a in kelas) {
        if (a != k) fpSum += cm[a]![k]!;
      }

      int fnSum = 0;
      for (var p in kelas) {
        if (p != k) fnSum += cm[k]![p]!;
      }

      double p = (tp + fpSum) == 0 ? 0 : tp / (tp + fpSum);
      double r = (tp + fnSum) == 0 ? 0 : tp / (tp + fnSum);
      double f = (p + r) == 0 ? 0 : 2 * p * r / (p + r);

      precision[k] = p;
      recall[k] = r;
      f1[k] = f;
    }

    akurasi = totalData == 0 ? 0 : totalBenar / totalData * 100;
    macroPrecision = precision.values.fold(0.0, (a, b) => a + b) / kelas.length;
    macroRecall = recall.values.fold(0.0, (a, b) => a + b) / kelas.length;
    macroF1 = f1.values.fold(0.0, (a, b) => a + b) / kelas.length;

    setState(() => loading = false);
  }

  Color warnaKelas(String k) {
    if (k == 'Aman') return Colors.green;
    if (k == 'Mendekati') return Colors.orange;
    return Colors.red;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Evaluasi Model KNN'),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : totalData == 0
          ? const Center(child: Text('Belum ada data barang untuk dievaluasi.'))
          : SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            // INFO TOTAL DATA
            Text(
              'Total data: $totalData  |  Prediksi benar: $totalBenar',
              style: const TextStyle(fontSize: 13, color: Colors.grey),
            ),
            const SizedBox(height: 16),

            // AKURASI
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.blue.shade50,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.blue.shade200),
              ),
              child: Column(
                children: [
                  const Text('Akurasi Model', style: TextStyle(fontSize: 14, color: Colors.blue)),
                  const SizedBox(height: 4),
                  Text(
                    '${akurasi.toStringAsFixed(2)}%',
                    style: const TextStyle(fontSize: 36, fontWeight: FontWeight.bold, color: Colors.blue),
                  ),
                  Text(
                    '$totalBenar dari $totalData data diprediksi benar',
                    style: const TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // CONFUSION MATRIX
            const Text('Confusion Matrix', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            const SizedBox(height: 4),
            const Text('Baris = Aktual, Kolom = Prediksi', style: TextStyle(fontSize: 12, color: Colors.grey)),
            const SizedBox(height: 8),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Table(
                border: TableBorder.all(color: Colors.grey.shade300),
                defaultColumnWidth: const FixedColumnWidth(100),
                children: [
                  // Header
                  TableRow(
                    decoration: BoxDecoration(color: Colors.grey.shade100),
                    children: [
                      const Padding(
                        padding: EdgeInsets.all(8),
                        child: Text('Aktual \\ Pred', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
                      ),
                      ...kelas.map((k) => Padding(
                        padding: const EdgeInsets.all(8),
                        child: Text(k, style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: warnaKelas(k)), textAlign: TextAlign.center),
                      )),
                    ],
                  ),
                  // Rows
                  ...kelas.map((aktual) => TableRow(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8),
                        child: Text(aktual, style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: warnaKelas(aktual))),
                      ),
                      ...kelas.map((pred) {
                        bool isDiagonal = aktual == pred;
                        int val = cm[aktual]![pred]!;
                        return Container(
                          color: isDiagonal ? Colors.green.shade50 : (val > 0 ? Colors.red.shade50 : null),
                          padding: const EdgeInsets.all(8),
                          child: Text(
                            '$val',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              color: isDiagonal ? Colors.green.shade700 : (val > 0 ? Colors.red.shade700 : Colors.black),
                            ),
                          ),
                        );
                      }),
                    ],
                  )),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // METRIK PER KELAS
            const Text('Metrik per Kelas', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            const SizedBox(height: 8),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Table(
                border: TableBorder.all(color: Colors.grey.shade300),
                defaultColumnWidth: const FixedColumnWidth(90),
                children: [
                  TableRow(
                    decoration: BoxDecoration(color: Colors.grey.shade100),
                    children: const [
                      Padding(padding: EdgeInsets.all(8), child: Text('Kelas', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11))),
                      Padding(padding: EdgeInsets.all(8), child: Text('Precision', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11), textAlign: TextAlign.center)),
                      Padding(padding: EdgeInsets.all(8), child: Text('Recall', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11), textAlign: TextAlign.center)),
                      Padding(padding: EdgeInsets.all(8), child: Text('F1-Score', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11), textAlign: TextAlign.center)),
                    ],
                  ),
                  ...kelas.map((k) => TableRow(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8),
                        child: Text(k, style: TextStyle(fontSize: 11, color: warnaKelas(k), fontWeight: FontWeight.bold)),
                      ),
                      Padding(padding: const EdgeInsets.all(8), child: Text(precision[k]!.toStringAsFixed(2), textAlign: TextAlign.center, style: const TextStyle(fontSize: 12))),
                      Padding(padding: const EdgeInsets.all(8), child: Text(recall[k]!.toStringAsFixed(2), textAlign: TextAlign.center, style: const TextStyle(fontSize: 12))),
                      Padding(padding: const EdgeInsets.all(8), child: Text(f1[k]!.toStringAsFixed(2), textAlign: TextAlign.center, style: const TextStyle(fontSize: 12))),
                    ],
                  )),
                  // Macro average
                  TableRow(
                    decoration: BoxDecoration(color: Colors.blue.shade50),
                    children: [
                      const Padding(padding: EdgeInsets.all(8), child: Text('Macro Avg', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11))),
                      Padding(padding: const EdgeInsets.all(8), child: Text(macroPrecision.toStringAsFixed(2), textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12))),
                      Padding(padding: const EdgeInsets.all(8), child: Text(macroRecall.toStringAsFixed(2), textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12))),
                      Padding(padding: const EdgeInsets.all(8), child: Text(macroF1.toStringAsFixed(2), textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12))),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // KETERANGAN
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.grey.shade50,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.grey.shade200),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Keterangan:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                  SizedBox(height: 4),
                  Text('• Label aktual ditentukan dari aturan bisnis:\n  Aman (>30 hari), Mendekati (1–30 hari), Kedaluwarsa (≤0 hari)', style: TextStyle(fontSize: 11, color: Colors.grey)),
                  SizedBox(height: 4),
                  Text('• Diagonal hijau = prediksi benar (True Positive)', style: TextStyle(fontSize: 11, color: Colors.grey)),
                  SizedBox(height: 4),
                  Text('• Sel merah = prediksi salah', style: TextStyle(fontSize: 11, color: Colors.grey)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}