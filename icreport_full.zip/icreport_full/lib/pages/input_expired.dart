import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../db/database_helper.dart';

class InputExpiredPage extends StatefulWidget {
  const InputExpiredPage({super.key});
  @override State<InputExpiredPage> createState() => _InputExpiredPageState();
}

class _InputExpiredPageState extends State<InputExpiredPage> {
  String? barcode;
  final nameC = TextEditingController();
  DateTime? selected;
  String? retur;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final args = ModalRoute.of(context)!.settings.arguments;
    if (args != null && args is String) barcode = args;
  }

  Future pickDate() async {
    DateTime now = DateTime.now();
    DateTime? d = await showDatePicker(context: context, initialDate: now, firstDate: DateTime(2020), lastDate: DateTime(2050));
    if (d != null) {
      setState(() {
        selected = d;
        retur = DateFormat('yyyy-MM-dd').format(d.subtract(const Duration(days:30)));
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Input Expired')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          if (barcode != null) Text('Barcode: $barcode'),
          TextField(controller: nameC, decoration: const InputDecoration(labelText: 'Nama Barang')),
          const SizedBox(height: 12),
          ElevatedButton(onPressed: pickDate, child: const Text('Pilih Tanggal Expired')),
          const SizedBox(height: 8),
          if (selected != null) Text('Expired: ${DateFormat('yyyy-MM-dd').format(selected!)}'),
          if (retur != null) Text('Tanggal Retur: $retur'),
          const SizedBox(height: 16),
          ElevatedButton(
              onPressed: () async {
                if (nameC.text.trim().isEmpty || selected == null) return;
                await DatabaseHelper().insertItem({
                  'barcode': barcode ?? '',
                  'nama_barang': nameC.text.trim(),
                  'expired_date': DateFormat('yyyy-MM-dd').format(selected!),
                  'tanggal_retur': retur ?? ''
                });
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Data disimpan')));
                  Navigator.popUntil(context, ModalRoute.withName('/home'));
                }
              },
              child: const Text('Simpan')
          )
        ]),
      ),
    );
  }
}
