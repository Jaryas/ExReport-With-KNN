import 'package:flutter/material.dart';

class NotifBanner extends StatelessWidget {
  final String message;
  const NotifBanner({super.key, required this.message});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      color: Colors.orange,
      padding: const EdgeInsets.all(12),
      child: Text(message, style: const TextStyle(color: Colors.white)),
    );
  }
}
