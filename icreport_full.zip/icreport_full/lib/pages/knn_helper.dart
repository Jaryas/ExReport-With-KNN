class KNNHelper {

  static String classify(int selisihHari) {

    // DATA TRAINING
    List<Map<String, dynamic>> training = [

      // AMAN (>30 hari)
      {'hari': 90, 'label': 'Aman'},
      {'hari': 75, 'label': 'Aman'},
      {'hari': 65, 'label': 'Aman'},
      {'hari': 60, 'label': 'Aman'},
      {'hari': 50, 'label': 'Aman'},
      {'hari': 45, 'label': 'Aman'},
      {'hari': 40, 'label': 'Aman'},
      {'hari': 33, 'label': 'Aman'},

      // MENDEKATI (1-30 hari)
      {'hari': 28, 'label': 'Mendekati'},
      {'hari': 25, 'label': 'Mendekati'},
      {'hari': 20, 'label': 'Mendekati'},
      {'hari': 15, 'label': 'Mendekati'},
      {'hari': 14, 'label': 'Mendekati'},
      {'hari': 10, 'label': 'Mendekati'},
      {'hari': 7, 'label': 'Mendekati'},
      {'hari': 5, 'label': 'Mendekati'},
      {'hari': 3, 'label': 'Mendekati'},

      // KEDALUWARSA (<=0 hari)
      {'hari': 0, 'label': 'Kedaluwarsa'},
      {'hari': -1, 'label': 'Kedaluwarsa'},
      {'hari': -3, 'label': 'Kedaluwarsa'},
      {'hari': -5, 'label': 'Kedaluwarsa'},
      {'hari': -7, 'label': 'Kedaluwarsa'},
      {'hari': -10, 'label': 'Kedaluwarsa'},
      {'hari': -20, 'label': 'Kedaluwarsa'},
    ];

    // HITUNG JARAK
    for (var d in training) {
      d['jarak'] = (selisihHari - d['hari']).abs();
    }

    // SORTING BERDASARKAN JARAK TERKECIL
    training.sort((a, b) => a['jarak'].compareTo(b['jarak']));

    // NILAI K
    int k = 3;

    // AMBIL K TETANGGA TERDEKAT
    List nearest = training.take(k).toList();

    // VOTING
    Map<String, int> voting = {};

    for (var n in nearest) {
      String label = n['label'];

      if (voting.containsKey(label)) {
        voting[label] = voting[label]! + 1;
      } else {
        voting[label] = 1;
      }
    }

    // CARI LABEL TERBANYAK
    String hasil = '';
    int maxVote = 0;

    voting.forEach((label, jumlah) {
      if (jumlah > maxVote) {
        maxVote = jumlah;
        hasil = label;
      }
    });

    return hasil;
  }
}