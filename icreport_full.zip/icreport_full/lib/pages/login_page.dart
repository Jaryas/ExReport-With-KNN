import 'package:flutter/material.dart';
import '../db/database_helper.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final userC = TextEditingController();
  final passC = TextEditingController();
  String error = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Login')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: userC, decoration: const InputDecoration(labelText: 'Username')),
            TextField(controller: passC, decoration: const InputDecoration(labelText: 'Password'), obscureText: true),
            const SizedBox(height: 12),
            Text(error, style: const TextStyle(color: Colors.red)),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () async {
                bool ok = await DatabaseHelper().login(userC.text.trim(), passC.text.trim());
                if (ok) {
                  Navigator.pushReplacementNamed(context, '/home');
                } else {
                  setState(() => error = 'Username atau password salah');
                }
              },
              child: const Text('Login')
            )
          ]),
        ),
      ),
    );
  }
}
