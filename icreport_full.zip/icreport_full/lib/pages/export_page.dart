import 'package:flutter/material.dart';
import 'package:excel/excel.dart';
import 'dart:io';
import 'package:permission_handler/permission_handler.dart';
import 'package:path_provider/path_provider.dart';
import '../db/database_helper.dart';

class ExportPage extends StatefulWidget {
  const ExportPage({super.key});

  @override
  State<ExportPage> createState() => _ExportPageState();
}

class _ExportPageState extends State<ExportPage> {
  String status = '';

  // Request permission storage
  Future<bool> _requestPermission() async {
    var storageStatus = await Permission.storage.status;
    if (!storageStatus.isGranted) {
      storageStatus = await Permission.storage.request();
    }

    // Android 11+ manage external storage
    if (await Permission.manageExternalStorage.isDenied) {
      await Permission.manageExternalStorage.request();
    }

    return storageStatus.isGranted || await Permission.manageExternalStorage.isGranted;
  }

  // Simpan file ke Downloads
  Future<String> saveExcelToDownload(List<int> bytes) async {
    final permissionGranted = await _requestPermission();
    if (!permissionGranted) return 'Permission denied!';

    Directory? directory;

    // Gunakan path_provider untuk folder Downloads
    try {
      directory = await getDownloadsDirectory();
      if (directory == null) {
        return 'Folder Download tidak ditemukan';
      }
    } catch (e) {
      return 'Error mengambil folder Download: $e';
    }

    final filePath = '${directory.path}/data_expired.xlsx';
    final file = File(filePath);

    await file.writeAsBytes(bytes);
    return filePath;
  }

  // Generate Excel dari database
  Future<String> generateExcel() async {
    var excel = Excel.createExcel();
    Sheet sheet = excel['Data'];

    // Header kolom
    sheet.appendRow([
      'ID',
      'Barcode',
      'Nama',
      'Expired',
      'Retur',
      'ScannedAt'
    ]);

    // Ambil data dari database
    List data = await DatabaseHelper().getItems(orderBy: 'expired_date ASC');

    for (var d in data) {
      sheet.appendRow([
        d['id'],
        d['barcode'],
        d['nama_barang'],
        d['expired_date'],
        d['tanggal_retur'],
        d['scanned_at'] ?? ''
      ]);
    }

    // Encode menjadi bytes
    final bytes = excel.encode()!;
    // Simpan ke folder Download
    return await saveExcelToDownload(bytes);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Export Excel')),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ElevatedButton(
              onPressed: () async {
                setState(() => status = 'Membuat file...');
                String path = await generateExcel();
                setState(() => status = 'Selesai: $path');

                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('File disimpan di: $path')),
                );
              },
              child: const Text('Generate Excel'),
            ),
            const SizedBox(height: 12),
            Text(status),
          ],
        ),
      ),
    );
  }
}
