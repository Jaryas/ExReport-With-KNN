import 'package:flutter/material.dart';
import 'pages/login_page.dart';
import 'pages/home_page.dart';
import 'pages/scan_page.dart';
import 'pages/input_expired.dart';
import 'pages/list_barang.dart';
import 'pages/export_page.dart';
import 'pages/evaluasi_page.dart'; // TAMBAH INI
import 'db/database_helper.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await DatabaseHelper().database;
  runApp(const ExpiredApp());
}

class ExpiredApp extends StatelessWidget {
  const ExpiredApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ICReport - Expired Monitor',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.indigo),
      initialRoute: '/',
      routes: {
        '/': (c) => const LoginPage(),
        '/home': (c) => const HomePage(),
        '/scan': (c) => const ScanPage(),
        '/input': (c) => const InputExpiredPage(),
        '/list': (c) => const ListBarangPage(),
        '/export': (c) => const ExportPage(),
        '/evaluasi': (c) => const EvaluasiPage(), // TAMBAH INI
      },
    );
  }
}