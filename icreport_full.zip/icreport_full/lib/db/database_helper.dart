import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static final _databaseName = "icreport_full.db";
  static final _databaseVersion = 1;

  static final tableUsers = 'users';
  static final tableItems = 'items';

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB();
    return _database!;
  }

  Future<Database> _initDB() async {
    String path = join(await getDatabasesPath(), _databaseName);
    return await openDatabase(path, version: _databaseVersion, onCreate: _onCreate);
  }

  Future _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE $tableUsers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        password TEXT NOT NULL
      );
    ''');

    await db.execute('''
      CREATE TABLE $tableItems (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        barcode TEXT,
        nama_barang TEXT NOT NULL,
        expired_date TEXT NOT NULL,
        tanggal_retur TEXT NOT NULL,
        scanned_at TEXT
      );
    ''');

    // default user
    await db.insert(tableUsers, {"username":"admin", "password":"admin123"});
  }

  // login
  Future<bool> login(String user, String pass) async {
    final db = await database;
    final res = await db.query(tableUsers, where: "username = ? AND password = ?", whereArgs: [user, pass]);
    return res.isNotEmpty;
  }

  // insert item
  Future<int> insertItem(Map<String, dynamic> row) async {
    final db = await database;
    return await db.insert(tableItems, row);
  }

  Future<List<Map<String, dynamic>>> getItems({String orderBy = 'expired_date ASC'}) async {
    final db = await database;
    return await db.query(tableItems, orderBy: orderBy);
  }

  Future<int> deleteItem(int id) async {
    final db = await database;
    return await db.delete(tableItems, where: 'id = ?', whereArgs: [id]);
  }

  Future<int> updateItem(int id, Map<String, dynamic> row) async {
    final db = await database;
    return await db.update(tableItems, row, where: 'id = ?', whereArgs: [id]);
  }
}
